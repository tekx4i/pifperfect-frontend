import React, { useState, useEffect } from 'react'
import FormWithLabel from './Component/FieldWithLabel'
import { ReactSVG } from "react-svg";
import { salesManagerForm } from './metricData';
import SM from "../../../assets/newImages/user-octagon.svg"
import SR from "../../../assets/newImages/setterrep.svg"
import CR from "../../../assets/newImages/closerrep.svg"
import SMA from "../../../assets/newImages/user-octagon-active.svg"
import SRA from "../../../assets/newImages/setterrep-active.svg"
import CRA from "../../../assets/newImages/closerrep-active.svg"
import checkIcon from "../../../assets/newImages/tick-circle.svg"
import { useForm } from "react-hook-form";
import { apiPost } from '../../../CustomHooks/useAuth';

const MetricGoal = () => {

    const { register, handleSubmit, formState: { errors }, reset, setValue, watch } = useForm();

    const { REACT_APP_API_URL } = process.env

    const [tab, setTab] = useState(1);
    const [role, setRole] = useState(3);
    const [user, setUser] = useState()
    const [loading, setIsLoading] = useState()

    const token = localStorage.getItem("token")

    const onSubmit = async (data) => {
        try {

            const url = `${REACT_APP_API_URL}metrics`;


            // Prepare the URL with query parameters
            const params = ({
                roles: role,
                companyId: user.companyId,
                totalLeads: data.total_leads,
                totalDials: data.total_dials,
                convos: data.convos,
                sets: data.sets,
                setsCalendar: data.sets_calendar,
                liveCalls: data.live_calls,
                setsOffered: data.sets_offered,
                setsClosed: data.sets_closed,
                currency: data.currency,
                salesTarget: data.sales_target,
            });


            // Send the request
            const response = await apiPost(url, params, token);
            if (response.success) {
                // setIsOpenModal(false);
                // reset();
                // getUser();
            }
        } catch (error) {
            console.log(error);
        } finally {
            setIsLoading(false);
        }
    };


    useEffect(() => {
        // Get user info from local storage
        const storedUser = localStorage.getItem("userInfo");
        if (storedUser) {
            setUser(JSON.parse(storedUser)); // Parse the JSON string
        }
    }, []);



    // const userRoles=localStorage.getItem("userInfo")

    return (
        <div className="page-content" id="user-management">
            <div className="custom-container mt-4">
                <div className="custom-tabs">
                    <button className={`custom-tab-btn ${tab === 1 ? "active" : ""}`} onClick={() => { setTab(1); setRole(3) }}>
                        <ReactSVG src={tab === 1 ? SMA : SM} /> <span>Sales Manager</span>
                    </button>
                    <button className={`custom-tab-btn ${tab === 2 ? "active" : ""}`} onClick={() => { setTab(2); setRole(4) }}>
                        <ReactSVG src={tab === 2 ? SRA : SR} /> <span>Setter Rep</span>
                    </button>
                    <button className={`custom-tab-btn ${tab === 3 ? "active" : ""}`} onClick={() => { setTab(3); setRole(5); }}>
                        <img src={tab === 3 ? CRA : CR} /> <span>Closer Rep</span>
                    </button>
                </div>


                <div className="ctm-form px-0 mt-0">

                    <form onSubmit={handleSubmit(onSubmit)}>
                        <div className='row'>
                            {/* {salesManagerForm.map(field => (
                            field.type != 'dropdown' ? 
                            <FormWithLabel
                                label={field.label}
                                fieldType={field.type}
                                placeholderText={field.placeholder}
                                fieldId={field.fieldId}
                            /> : 
                            tab === 1 && (
                                <div className="col-md-6">
                                    <label className="form-label">{field.label}</label>
                                    <select className="form-select">
                                        {field.options.map(option => (
                                        <option value={option}>{option}</option>
                                        ))}
                                    </select>
                                </div>
                            )))} */}

                            <div className="col-md-6 mb-4">
                                <label className="form-label">Total Leads</label>
                                <input type='number' className="form-control" placeholder='100' {...register("total_leads")} />
                            </div>

                            <div className="col-md-6 mb-4">
                                <label className="form-label">Total Dials</label>
                                <input type='number' className="form-control" placeholder='50' {...register("total_dials")} />
                            </div>

                            <div className="col-md-6 mb-4">
                                <label className="form-label">Meaningful Convos/Triages</label>
                                <input type='number' className="form-control" placeholder='25' {...register("convos")} />
                            </div>

                            <div className="col-md-6 mb-4">
                                <label className="form-label">Sets</label>
                                <input type='number' className="form-control" placeholder='5'{...register("sets")} />
                            </div>

                            <div className="col-md-6 mb-4">
                                <label className="form-label">Sets on calendar</label>
                                <input type='number' className="form-control" placeholder='5'{...register("sets_calendar")} />
                            </div>

                            <div className="col-md-6 mb-4">
                                <label className="form-label">Live Calls</label>
                                <input type='number' className="form-control" placeholder='5' {...register("live_calls")} />
                            </div>

                            <div className="col-md-6 mb-4">
                                <label className="form-label">Sets Offered</label>
                                <input type='number' className="form-control" placeholder='3' {...register("sets_offered")} />
                            </div>

                            <div className="col-md-6 mb-4">
                                <label className="form-label">Sets Closed</label>
                                <input type='number' className="form-control" placeholder='2' {...register("sets_closed")} />
                            </div>

                            <div className="col-md-6 mb-4">
                                <label className="form-label">Sales Target</label>
                                <input type='number' className="form-control" placeholder='2' {...register("sales_target")} />
                            </div>

                            {
                                role === 3 &&
                                <div className="col-md-6">
                                    <label className="form-label">Select type of currency</label>
                                    <select className="form-select" {...register("currency")}>
                                        {/* {field.options.map(option => (
                                        <option value={option}>{option}</option>
                                    ))} */}
                                        <option>$USD</option>
                                    </select>
                                </div>
                            }


                        </div>
                        <button className="custom_submit_btn mt-3">
                            <ReactSVG src={checkIcon} /> Set Matrix
                        </button>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default MetricGoal

