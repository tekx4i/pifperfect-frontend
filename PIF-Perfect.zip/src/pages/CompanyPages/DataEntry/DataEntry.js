import React, { useEffect, useState } from "react";
import { Table } from "reactstrap";
import { Link } from "react-router-dom";
import { ReactSVG } from "react-svg";
import SkeletonLoader from "../../../helpers/SkeltonLoader";
import userDummy from "../../../assets/newImages/about.jpg";
import editIcon from "../../../assets/newImages/edit.svg";
import eyeIcon from "../../../assets/newImages/eye.svg";

import closeIcon from "../../../assets/newImages/close-circle.svg";
import { apiGet, apiPut } from "../../../CustomHooks/useAuth";
import dayjs from "dayjs";
import { CiSearch } from "react-icons/ci";

const Company = () => {
  const [isLoading, setIsLoading] = useState(true); // Default to true
  const [users, setUsers] = useState([]);
  const token = localStorage.getItem("token");
  const { REACT_APP_API_URL, REACT_APP_API_IMG_URL } = process.env;
  // console.log("uuuuuuser",users.map((user)=>(console.log(user.logo))))
  const [searchQuery, setSearchQuery] = useState(""); // State for search query

  const getCompanies = async () => {
    setIsLoading(true);
    try {
      // const url = `https://phpstack-1250693-5093481.cloudwaysapps.com/api/companies`;

      const url = `${REACT_APP_API_URL}companies/1/users?name=Company`;

      const response = await apiGet(url, {}, token);

      if (response.success) {
        setUsers(response.data.records);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    getCompanies();
  }, []);

  const deactivateCompany = async (id, currentStatus) => {
    if (!token) {
      console.error("Authorization token is missing.");
      return;
    }
    try {
      const url = `${REACT_APP_API_URL}companies/update/${id}`;
      // const url = `https://phpstack-1250693-5093481.cloudwaysapps.com/api/companies/update/${id}`;

      const params = { isActive: !currentStatus };
      const response = await apiPut(url, params, token);

      if (response.success) {
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user.id === id ? { ...user, isActive: !currentStatus } : user
          )
        );
      }
    } catch (error) {
      console.error("Error toggling company status:", error);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    // const value = e.target.value;

    // setSearchQuery(value);

    // Debounced search
    setTimeout(() => {
      getCompanies(searchQuery); // Fetch data based on search query
    }, 500);
  };

  return (
    <div className="page-content" id="companies">
      <div className="custom-header-ctm">
        <div className="row w-100 m-0">
          <div className="col-md-6 p-0">
            <h4 className="w-100">Data Entry</h4>
          </div>
          <div className="col-md-6 p-0">
            <div className="add-btns justify-conten-end">
              <form onSubmit={handleSearch}>
                <div className="search-ctm">
                  <input
                    placeholder="Search data entry by name"
                    value={searchQuery}
                    // onChange={handleSearch} // Handle input change
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <button type="submit">
                    <CiSearch />
                  </button>
                </div>
              </form>
              <Link to="/company/data-entry/add" className="default__btn">
                <span>Add Data Entry</span>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="custom-container">
        <div className="table-responsive mt-3">
          {
            // Show the table when data is loaded
            <Table className="align-middle table-nowrap mb-0">
              <thead>
                <tr>
                  <th scope="col">Candidate Name</th>
                  <th scope="col">User Role</th>
                  <th scope="col">Date Joined</th>
                  <th scope="col">Location</th>
                  <th scope="col">Status</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  // Show SkeletonLoader when loading
                  <SkeletonLoader
                    rows={4}
                    columns={[200, 150, 100, 150, 100, 150]}
                    width="100%"
                    height={40}
                  />
                ) : users.length > 0 ? (
                  users.map((user) => (
                    <tr key={user.id}>
                      <td className="fw-medium">
                        <div className="user-img">
                          <img
                            src={
                              user.image
                                ? `${REACT_APP_API_IMG_URL}${user.image}`
                                : "https://www.londondentalsmiles.co.uk/wp-content/uploads/2017/06/person-dummy.jpg"
                            }
                            alt="user"
                          />
                          {user?.firstName}
                        </div>
                      </td>
                      <td>
                        <span className="ctm-badge warning">Company Admin</span>
                      </td>
                      <td>{user.createdAt}</td>
                      <td>{user.address}</td>
                      {/* Uncomment if needed */}
                      {/* <td>{dayjs(user.establishedDate).format("DD-MM-YYYY")}</td> */}
                      <td>
                        <span className="ctm-badge disabled">
                          <span className="active-dot"></span>Active
                        </span>
                      </td>
                      <td>
                        <div className="d-flex">
                          <Link className="action-btn bg-transparent">
                            <ReactSVG src={eyeIcon} /> View Details
                          </Link>
                        </div>
                      </td>
                      {/* Uncomment if needed */}
                      {/* <td>
            <div className="d-flex gap-2">
              <Link
                onClick={() => deactivateCompany(user.id, user.isActive)}
                className={`action-btn ${user.isActive ? "deactivate" : "activate"}`}
              >
                <ReactSVG src={closeIcon} />
                {user.isActive ? "Deactivate" : "Activate"}
              </Link>
              <Link to={`/company/add/${user.id}`} className="action-btn edit">
                <ReactSVG src={editIcon} />
              </Link>
            </div>
          </td> */}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="text-center">
                      No Data Found
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
          }
        </div>
      </div>
    </div>
  );
};

export default Company;
